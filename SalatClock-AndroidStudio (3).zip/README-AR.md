# مشروع أندرويد جاهز لـ ساعة الصلاة

يحتوي هذا المجلد على مشروع Android Studio كامل بلغة Kotlin مع دعم الهواتف والأجهزة اللوحية وشاشات Android TV.

## المميزات المدمجة:
- ملفك الأصلي مدمج بالكامل في: `app/src/main/assets/index.html`
- إبقاء الشاشة مضاءة تلقائياً (`FLAG_KEEP_SCREEN_ON`)
- وضع ملء الشاشة التلقائي (Immersive Fullscreen)
- دعم تحديد الموقع GPS واختيار صورة خلفية من المعرض
- دعم أجهزة Android TV (`LEANBACK_LAUNCHER`)

## خطوات بناء ملف APK عبر Android Studio:
1. افتح برنامج **Android Studio**.
2. اختر **Open** ثم حدد هذا المجلد بعد فك الضغط.
3. انتظر اكتمال مزامنة Gradle، ثم من القائمة العلوية اختر:
   **Build > Build Bundle(s) / APK(s) > Build APK(s)**

## أو البناء السحابي تلقائياً عبر GitHub (بدون Android Studio):
تم تضمين ملف `.github/workflows/build-apk.yml`؛ بمجرد رفع المشروع إلى GitHub وتشغيل Actions ستحصل على ملف `app-debug.apk` جاهز للتحميل.
